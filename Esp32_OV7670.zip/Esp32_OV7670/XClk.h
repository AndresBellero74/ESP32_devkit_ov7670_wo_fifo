#pragma once

bool ClockEnable(int pin, int Hz);
void ClockDisable();
